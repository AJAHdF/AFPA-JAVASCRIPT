document.getElementById('p1').innerHTML =
    'Taille de la fenêtre (ext) : ' + window.outerWidth + '*' + window.outerHeight;

document.getElementById('p2').innerHTML = 
    'Taille de la fenêtre (int) : ' + window.innerWidth + '*' + window.innerHeight;